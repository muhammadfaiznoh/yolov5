# test-tube > 2023-06-23 9:48am
https://universe.roboflow.com/muhammad-faiz-noh-glbe0/test-tube-jph4y

Provided by a Roboflow user
License: CC BY 4.0

